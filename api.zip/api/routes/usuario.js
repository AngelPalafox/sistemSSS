const user = require("../controller/usuario");
const token = require('../middleware/token.js')
var router = require("express").Router();

router.post("/login", user.login);
router.post("/create",user.create);
router.post("/codigo_verificacion",user.codigoVerificacion);

module.exports = router
