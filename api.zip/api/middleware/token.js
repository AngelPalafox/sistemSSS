const jwt = require("jsonwebtoken")
const bcrypt = require("bcryptjs");
const jwtC = 'AccessTokenPrivate'

const validT = (req, res, next) => {
    var token = req.headers['authorization']

    let decode
    if (!token) {
        res.status(500).send('No existe token')
    }
    else {
        try {
            decode = jwt.verify(token, jwtC)
        }
        catch (e) {
            res.status(501).send(
                {
                    message: "TOKEN NO VALIDO"
                }
            )
        }

        if (decode) {
            res.status(200).send(
                {
                    message: "TOKEN  VALIDO"
                }
            )
        }

    }
}
const validTs = (req, res, next) => {
    var token = req.headers['authorization']
    let decode
    if (!token) {
        res.status(500).send('No existe token')
    }
    else {
        try {
            decode = jwt.verify(token, jwtC)
        }
        catch (e) {
            res.status(501).send(
                {
                    message: "TOKEN NO VALIDO"
                }
            )
        }

        if (decode) {
            next()
        }

    }
}


module.exports = {
    validT, validTs
}