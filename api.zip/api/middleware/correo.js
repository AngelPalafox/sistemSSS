const nodemailer = require("nodemailer");
const transporter = nodemailer.createTransport({
    host: 'smtp.gmail.com',
    auth: {
        user: "angelpalafox034@gmail.com",
        pass: "twctaklnahorjsss",
    }
});
const email = (req, res) => {

    async function main() {
        const info = await transporter.sendMail({
            from: 'angelpalafox034@gmail.com',
            to: req.correo,
            subject: "Código de Verificación",
            text: "Código de verificación: " + req.codigo,
            html: '',

        });

    }

    main()
        .then(
            res.status(200).send(
                {
                    message: 'código enviado!'
                })

        )
        .catch(console.error);

}


module.exports = {
    email
}