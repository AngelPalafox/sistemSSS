const jwt = require("jsonwebtoken")
const bcrypt = require("bcryptjs");
const e = require("express");
const jwtC = 'AccessTokenPrivate'
const db = require('../database/conexion')
const mail = require('../middleware/correo')
const create = (req, res) => {
    if (req.body.nombreUs != '') {
        if (req.body.correo != '') {
            if (req.body.password != '') {
                let datos = {
                    nombreUs: req.body.nombreUs,
                    correo: req.body.correo,
                    password: bcrypt.hashSync(req.body.password, 10),
                    rol: ''
                }
                db.any('SELECT * FROM  users_sistem').then((t) => {
                    if (t.length == 0) {
                        datos.rol = 'Administrador'

                    }
                    else {
                        datos.rol = 'Usuario'
                    }
                    db.any('INSERT INTO users_sistem(nombreUs,correo,password,rol) VALUES(${nombreUs},${correo},${password},${rol})', datos)
                        .then((t) => {
                            console.log(t)
                            res.status(200).send({
                                message:
                                    "Usuario Creado"
                            });
                        })
                        .catch(err => {
                            console.log(err)
                            res.status(500).send({
                                message:
                                    "Ocurrio algun error"
                            });
                        });
                })
                    .catch(err => {
                        console.log(err)
                        res.status(500).send({
                            message:
                                "Ocurrio algun error"
                        });
                    });
            }
            else {
                res.status(400).send({
                    message: ' el campo de contraseña esta vacío'
                })
            }
        }
        else {
            res.status(400).send({
                message: ' el campo de correo esta vacío'
            })
        }
    }
    else {
        res.status(400).send({
            message: ' el campo de nombreUs esta vacío'
        })
    }
};

const login = (req, res) => {
    let datos = {
        correo: req.body.correo
    }
    db.any('SELECT password,id FROM users_sistem WHERE correo = ${correo} LIMIT 1', datos)
        .then((t) => {
            if (bcrypt.compareSync(req.body.password, t[0].password)) {
                var rand = btoa(Math.random()).replaceAll('=', '')
                rand = rand.substring(rand.length - 6)
                let datos =
                {
                    codigo: bcrypt.hashSync(rand, 10),
                    id: t[0].id,
                    correo: req.body.correo
                }
                db.any('UPDATE users_sistem SET code_v = ${codigo} WHERE correo = ${correo} AND id = ${id}', datos)
                    .then((t) => {
                        let emailData =
                        {
                            codigo: rand,
                            correo: req.body.correo
                        }

                        mail.email(emailData, res)
                    }
                    )
                    .catch(err => {
                        console.log(err)
                        res.status(500).send({
                            message:
                                "Ocurrio algun error"
                        });
                    });
            }
            else {
                res.status(500).send({
                    message:
                        "Datos incorrectos!"
                });
            }
        })
        .catch(err => {
            console.log(err)
            res.status(500).send({
                message:
                    "Ocurrio algun error"
            });
        });
}

const codigoVerificacion = (req, res) => {
    let datos = {
        correo: req.body.correo,
    }
    db.any('SELECT code_v,id,rol,nombreus FROM users_sistem WHERE correo = ${correo}', datos).then((t) => {
        if (bcrypt.compareSync(req.body.code_v, t[0].code_v)) {
            const token = jwt.sign({ id: t[0].id, correo: t[0].correo }, jwtC, {

                expiresIn: '2h'

            })
            res.status(200).send({
                message: 'Sesión Creada!',
                datos: {
                    nombre: t[0].nombreus,
                    rol: t[0].rol,
                    token: token
                }
            })
        }
        else {
            res.status(500).send({
                message:
                    "Datos incorrecto"
            });
        }
    })
        .catch(err => {
            console.log(err)
            res.status(500).send({
                message:
                    "Ocurrio algun error"
            });
        });
}
module.exports = {
    create, login, codigoVerificacion
}