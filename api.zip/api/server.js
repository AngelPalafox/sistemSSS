const express = require("express");
const cors = require("cors");
const app = express();
const db = require('./database/conexion')
require('dotenv').config({ path: './.env' })

var corsOptions = {
  origin: process.env.cors
};

app.use(cors(corsOptions));

app.use(express.json());

app.use(express.urlencoded({ extended: true }));

const rute = require('./routes/routes.js')
app.use('/api', rute)


const PORT = process.env.puerto;
app.listen(PORT, () => {
  if (process.env.NODE_ENV == 'desarrollo') {
    console.log(`Server is running on port ${PORT}.`);
  }
  else {
    console.log('Server Running!')
  }


});


db.connect().then((t) => {
  console.log('Conexión Correcta')
})
  .catch((er) => {
    console.log(er)
  })